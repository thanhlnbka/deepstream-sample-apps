#
# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

from .pipeline import Pipeline
from .flow import Flow
from ._pydeepstream.utils import *
from ._pydeepstream import BufferRetriever, Tensor

from typing import List, Tuple, Callable
from concurrent.futures import ThreadPoolExecutor
import queue

class MediaChunk:
    """Carries information of a chunk in a media source"""
    def __init__(self, source: str, start_pts: int=0, duration: int=-1):
        """
        Args:
            source: file path or url of a media source
            start_pts: timestamp in nano-second for start
            duration:  duration in nano-second
        """
        self._source = source
        self._start_pts = start_pts
        self._duration = duration

    @property
    def source(self):
        return self._source

    @property
    def start_pts(self):
        return self._start_pts

    @property
    def duration(self):
        return self._duration

class VideoFrame:
    """Represents a decoded video frame"""
    def __init__(self, data: Tensor, timestamp: int=-1):
        self._timestamp: int = -1
        self._tensor: Tensor = data

    @property
    def timestamp(self):
        return self._timestamp

    @property
    def tensor(self):
        return self._tensor

class VideoFrameRetriever(BufferRetriever):
    def __init__(self, chunks: List[MediaChunk], qs: list[queue.Queue], filter: Callable[[MediaChunk, int, int], bool]):
        super().__init__()
        self._chunks = chunks
        self._queues = qs
        self._filter = filter
        self._n_buffers = 0

    def consume(self, buffer):
        self._n_buffers += 1
        if (len(self._queues) == 1):
            # assuming no batch
            if (
                (callable(self._filter) and self._filter(self._chunks[0], buffer.timestamp, self._n_buffers))
                or self._filter is None
            ):
                frame = VideoFrame(buffer.extract(0).clone(), buffer.timestamp)
                self._queues[0].put(frame)
        else:
            for frame_meta in buffer.batch_meta.frame_items:
                id = frame_meta.pad_index
                pts = frame_meta.buffer_pts
                frame_number = frame_meta.frame_number
                if (
                    (callable(self._filter) and self._filter(self._chunks[id], pts, frame_number))
                    or self._filter is None
                ):
                    tensor = buffer.extract(frame_meta.batch_id)
                    frame = VideoFrame(tensor.clone(), pts)
                    self._queues[id].put(frame)
        return 1

class MediaExtractor:
    """Callable for extract data from media chunks"""
    DEFAULT_RESOLUTION = (1920, 1080)

    """
        Args:
            chunks    : a list of video chunk specification as input
            filter    : Callable[[chunk:MediaChunk, pts:int, frame_number:int] bool], callable for filtering the frames
            batch_size: 0 means no batch. once set to N, decoded frames will be batched and scaled
            scaling   : target resolution of (width, height), not applicable if batch_size is 0
            n_thread  : number of worker threads
            q_size    : the capacity of the output queue
    """
    def __init__(
            self,
            chunks: List[MediaChunk],
            filter: Callable[[MediaChunk, int, int], bool]=None,
            batch_size: int=0,
            scaling: Tuple=DEFAULT_RESOLUTION,
            n_thread: int=1,
            q_size: int=1
        ):
        self._pipelines = []
        self._flows = []
        self._chunks = chunks
        self._queues = [queue.Queue(maxsize=q_size) for _ in chunks]
        whole_list_of_chunks = [[c] for c in chunks]
        whole_list_of_queues = [[q] for q in self._queues]
        if batch_size > 0:
            # split the chunk list by batch size
            whole_list_of_chunks = [chunks[i: i + batch_size] for i in range(0, len(chunks), batch_size)]
            whole_list_of_queues = [self._queues[i: i + batch_size] for i in range(0, len(self._queues), batch_size)]
        for chunk_list, q_list in zip(whole_list_of_chunks, whole_list_of_queues):
            pipeline = Pipeline(f"media_extractor_pipeline")
            self._pipelines.append(pipeline)
            r = VideoFrameRetriever(chunk_list, q_list, filter)
            if batch_size == 0:
                assert(len(chunk_list) == 1)
                flow = Flow(pipeline).capture([chunk_list[0].source]).retrieve(r)
                if (chunk_list[0].start_pts > 0):
                    pipeline.seek(float(chunk_list[0].start_pts/1e9))
            else:
                sources = [chunk.source for chunk in chunk_list]
                flow = Flow(pipeline).batch_capture(sources, width=scaling[0], height=scaling[1]).retrieve(r)
            self._flows.append(flow)
        self._futures = []
        self._executor = ThreadPoolExecutor(max_workers=n_thread)

    def __enter__(self):
        return self

    def __exit__(self):
        self._executor.shutdown()

    def __call__(self):
        for flow in self._flows:
            future = self._executor.submit(lambda: flow())
            self._futures.append(future)
            future.add_done_callback(lambda f: self._futures.remove(f))
        return self._queues
