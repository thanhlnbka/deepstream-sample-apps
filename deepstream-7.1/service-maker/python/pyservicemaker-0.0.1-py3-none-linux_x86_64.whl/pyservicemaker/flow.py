#
# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

import os
import platform
from enum import Enum
from collections import namedtuple
from urllib.parse import urlparse
from ._pydeepstream import Receiver, BufferRetriever, Feeder, BufferProvider
from .pipeline import Pipeline
from .source_config import SourceConfig

class RenderMode(Enum):
    DISPLAY = 1
    DISCARD = 2


StreamInfo = namedtuple("StreamInfo", ['originator', 'template'])

def _populate_kwargs(properties, **kwargs):
    for key, value in kwargs.items():
        properties[key.replace('_', '-')] = value

def _parse_stream_info(info: str):
    items = info.split('/')
    return StreamInfo(
        originator=items[0],
        template=items[1] if len(items) == 2 else ''
    )

def _get_node_name(func, name) -> str:
    if not hasattr(func, "name_counter"):
        func.name_counter = 0
    else:
        func.name_counter += 1
    base_name = func.__name__.split('.')[-1]
    return f"{base_name}-{name}-{func.name_counter}"

def _validate_uri(uri: str):
    # parse the source uri
    parsed_uri = urlparse(uri)
    if not parsed_uri.scheme or parsed_uri.scheme == 'file':
        if not os.path.exists(parsed_uri.path):
            raise Exception(f"File {parsed_uri.path} doesn't exist")
        if not parsed_uri.scheme:
           uri = f"file://{parsed_uri.path}"
    return uri


class Flow:
    """
    The Flow class for constructing AI streaming flow
    """
    DEFAULT_PICTURE_WIDTH = 1920
    DEFAULT_PICTURE_HEIGHT = 1080
    DEFAULT_SOURCE_TYPE = "nvurisrcbin"

    def __init__(self, pipeline: Pipeline, streams=[], parent=None):
        """
        Initialize a new flow

        Args:
            pipeline(Pipeline): pipeline instance used by the flow
            streams(list[str]): list of stream descriptions
            parent(Flow):       parent flow from which the current flow is generated
        """
        self._pipeline = pipeline
        self._streams = streams
        self._parent = parent
        self._batch_size = parent._batch_size if parent else 0

    def __call__(self, on_message=None):
        """
        Activate the current flow.
        The call will not return until the flow is done
        Args:
            on_message (Callable[Pipeline, PipelineMessage]): message callback, optional
        """
        self._pipeline.start(on_message).wait()

    def capture(self, inputs: list, **kwargs):
        """
        Create a flow to capture a list of inputs, which creates one or more streams for
        any derived flow.

        Args:
            input(list(str)): list of input URIs
            kwargs:           key word argument for the source node
        Return: A derived flow
        Raises: TypeError
        """
        if not inputs:
            raise TypeError("No input list provided for capturing")
        func = Flow.capture
        streams = []
        for input in inputs:
            source = _get_node_name(func, 'source')
            source_properties = {"uri": _validate_uri(input)}
            _populate_kwargs(source_properties, **kwargs)
            self._pipeline.add(self.DEFAULT_SOURCE_TYPE, source, source_properties)
            streams.append(f"{source}/vsrc_%u")
        return Flow(self._pipeline, streams=streams, parent=self)

    def batch_capture(self, input, **kwargs):
        """
        Create a flow to capture multiple sources and batch them together

        Args:
            input(list(str) or str): list of URIs or a source config file
            **kwargs: width, height, batch-size are supported
        Return: A derived flow
        Raises: TypeError
        """
        func = Flow.batch_capture
        streams = []
        source_config = None
        uri_list = []
        gpu_id = kwargs["gpu_id"] if "gpu_id" in kwargs else 0
        source = _get_node_name(func, 'source')

        if isinstance(input, list):
            uri_list = input
        elif isinstance(input, str) and os.path.splitext(input)[1] in ['.yaml', '.yml']:
            source_config = SourceConfig()
            source_config.load(input)
            uri_list = [sensor.uri for sensor in source_config.sensor_list]
        else:
            raise TypeError("input must be a source list or source config file")

        if source_config and source_config.source_type == "nvmultiurisrcbin":
            source_properties = dict(source_config.source_properties)
            for k, v in [("width", self.DEFAULT_PICTURE_WIDTH), ("height", self.DEFAULT_PICTURE_HEIGHT)]:
                if k in kwargs:
                    source_properties[k] = kwargs[k]
                elif not k in source_properties:
                    source_properties[k] = v
            if "batch-size" in kwargs:
                source_properties["max-batch-size"] = kwargs["batch-size"]
            elif not "max-batch-size" in source_properties:
                source_properties["max-batch-size"] = len(source_config.sensor_list)
            source_properties["uri-list"] = ','.join([source.uri for source in source_config.sensor_list])
            source_properties["sensor-id-list"] = ','.join([source.sensor_id for source in source_config.sensor_list])
            source_properties["sensor-name-list"] = ','.join([source.sensor_name for source in source_config.sensor_list])
            self._pipeline.add("nvmultiurisrcbin", source, source_properties)
            streams.append(source)
            self._batch_size = len(source_config.sensor_list)
        else:
            streammux_properties = {
                "batch-size": len(uri_list),
                "gpu-id": gpu_id,
                "width": kwargs.pop("width", self.DEFAULT_PICTURE_WIDTH),
                "height": kwargs.pop("height", self.DEFAULT_PICTURE_HEIGHT)
            }
            mux = _get_node_name(func, 'mux')
            self._pipeline.add("nvstreammux", mux, streammux_properties)
            for i, uri in enumerate(uri_list):
                source_properties = {"uri": _validate_uri(uri), "gpu-id": gpu_id}
                source_name = f"{source}_{i}"
                source_type = source_config.source_type if source_config else self.DEFAULT_SOURCE_TYPE
                if source_config:
                    for k, v in source_config.source_properties.items():
                        if not k in ["width", "height"]:
                            source_properties[k] = v
                self._pipeline.add(source_type, source_name, source_properties).link((source_name, mux), ("vsrc_%u", ""))
            streams.append(mux)
            self._batch_size = len(uri_list)

        return Flow(self._pipeline, streams=streams, parent=self)

    def inject(self, providers: list, **kwargs):
        """
        Inject raw data to the pipeline by creating buffers
        Supported format:
            raw:     ["RGB", "RGBA", "I420"]
            encoded: ["JPEG"]
        Args:
            provider(list(BufferProvider)): list of providers, width/height/format/framerate/device must be supplied
        Return: A derived flow
        Raises: TypeError
        """
        if not providers:
            raise TypeError("List of providers must be supplied for injecting data")
        streams = []
        for provider in providers:
            raw_data = True if provider.format in ["RGB", "RGBA", "I420"] else False
            if raw_data:
                mime = "video/x-raw(memory:NVMM)" if hasattr(provider, "device") and 'gpu' in provider.device else "video/x-raw"
            elif provider.format in ["JPG", "JPEG"]:
                mime = "image/jpeg"
            else:
                raise TypeError("Unsupported format for injected data")
            source = _get_node_name(Flow.inject, "source")
            converter = _get_node_name(Flow.inject, "converter")
            capsfilter = _get_node_name(Flow.inject, "capsfilter")
            feeder = _get_node_name(Flow.inject, "feeder")
            caps1 = f"{mime}, format={provider.format}, width={provider.width}, height={provider.height}, framerate={provider.framerate}/1"
            caps2 = f"video/x-raw(memory:NVMM), format=NV12, width=[{provider.width}], height={provider.height}, framerate={provider.framerate}/1"
            self._pipeline.add("appsrc", source, {
                "caps": caps1,
                "do-timestamp": True
            }).attach(source, Feeder(feeder, provider), tips="need-data/enough-data")
            if raw_data:
                self._pipeline.add("nvvideoconvert", converter,  {"gpu-id": kwargs.pop("gpu_id", 0)})
                self._pipeline.add("capsfilter", capsfilter, {"caps": caps2})
                self._pipeline.link(source, converter, capsfilter)
                streams.append(capsfilter)
            else:
                streams.append(source)

        return Flow(self._pipeline, streams=streams, parent=self)


    def retrieve(self, retriever: BufferRetriever, **kwargs):
        """
        Retrieve the buffer from the pipeline.
        If users want to reuse the data in the buffer, it must be
        copied out from the callback, otherwise it'll be disposed
        by the pipeline.
        Args:
            retriever(BufferRetriever): retriever object to pull the data
        Return: A derived flow
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        stream_info = _parse_stream_info(self._streams[0])
        converter = _get_node_name(Flow.retrieve, "converter")
        capsfilter = _get_node_name(Flow.retrieve, "capsfilter")
        sink = _get_node_name(Flow.retrieve, "appsink")
        receiver = _get_node_name(Flow.retrieve, "receiver")
        self._pipeline.add("nvvideoconvert", converter, {"gpu-id": kwargs.pop("gpu_id", 0)})
        self._pipeline.add("appsink", sink, {"emit-signals": True}).attach(sink, Receiver(receiver, retriever), tips="new-sample")
        self._pipeline.add("capsfilter", capsfilter, {"caps": "video/x-raw(memory:NVMM), format=RGB"})
        self._pipeline.link(converter, capsfilter, sink)
        if stream_info.template:
             self._pipeline.link(
                 (stream_info.originator, converter),
                 (stream_info.template, '')
             )
        else:
            self._pipeline.link(stream_info.originator, converter)
        return Flow(self._pipeline, parent=self)

    def batch(self, **kwargs):
        """
        Create a batch for buffers received from each upstream.
        By default, the batch size will be set to the number of upstreams
        Args:
            kwargs: overriding streammux properties(use in caution)
        Return: A derived flow
        Raises: Upstream Exception
        """
        #set the batch size
        if len(self._streams) == 0:
            raise Exception("Upstream error: no stream found")
        if self._batch_size != 0:
            raise Exception("Upstream error: already batched")

        # populate the properties from kwargs
        properties = {}
        _populate_kwargs(properties, **kwargs)
        if "batch-size" not in properties:
            properties["batch-size"] = len(self._streams)
        self._batch_size = properties["batch-size"]
        if "width" not in properties:
            properties["width"] = self.DEFAULT_PICTURE_WIDTH
        if "height" not in properties:
            properties["height"] = self.DEFAULT_PICTURE_HEIGHT

        mux_name = _get_node_name(Flow.batch, "mux")
        self._pipeline.add("nvstreammux", mux_name, properties)

        for stream in self._streams:
            stream_info = _parse_stream_info(stream)
            self._pipeline.link(
                (stream_info.originator, mux_name),
                (stream_info.template, "sink_%u")
            )

        return Flow(self._pipeline, streams=[mux_name], parent=self)

    def decode(self, **kwargs):
        """
        Add decoders to the pipeline
        Return: A derived flow
        """
        streams = []
        for i, stream in enumerate(self._streams):
            decoder_name = _get_node_name(Flow.decode, "decode")
            properties = {}
            _populate_kwargs(properties, **kwargs)
            self._pipeline.add("decodebin", decoder_name, properties)
            self._pipeline.link(stream, decoder_name)
            streams.append(f"{decoder_name}/src_%u")

        return Flow(self._pipeline, streams=streams, parent=self)

    def infer(self, config, **kwargs):
        """
        Enable inference in the pipeline
        Args:
            config: the inference configuration
            kwargs: for overriding inference configuration(use in caution)
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")

        config_file_path = None
        if not isinstance(config, str):
            raise TypeError("Inference config must be a file path")
        elif os.path.exists(config):
            config_file_path = config

        infer_name = _get_node_name(Flow.infer, "infer")
        properties = {"config-file-path": config_file_path} if config_file_path else {}
        _populate_kwargs(properties, **kwargs)
        if not "batch-size" in properties:
            properties["batch-size"] = self._batch_size
        self._pipeline.add("nvinfer", infer_name, properties)

        self._pipeline.link(self._streams[0], infer_name)

        return Flow(self._pipeline, streams=[infer_name], parent=self)

    def track(self, **kwargs):
        """
        Track the detected object, must come after primary inference
        Args:
            kwargs: standard tracker properties
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        tracker = _get_node_name(Flow.track, "tracker")
        properties = {}
        _populate_kwargs(properties, **kwargs)
        self._pipeline.add("nvtrackerbin", tracker, properties)
        self._pipeline.link(self._streams[0], tracker)
        return Flow(self._pipeline, streams=[tracker], parent=self)

    def render(self, mode: RenderMode = RenderMode.DISPLAY, enable_osd = True, **kwargs):
        """
        Render the video buffers on a display
        Args:
            mode:   renderer mode, DISCARD for dropping output
            enable_osd: enable Overlay Display
            kwargs: standard sink parameter with kwargs
        Return: A derived flow
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")

        properties = {}
        _populate_kwargs(properties, **kwargs)
        gpu_id = properties["gpu-id"] if "gpu-id" in properties else 0
        tiler_name = _get_node_name(Flow.render, "tiler")
        converter_name = _get_node_name(Flow.render, "convert")
        osd_name = _get_node_name(Flow.render, "osd")
        sink_type = "fakesink"
        if mode == RenderMode.DISPLAY:
            sink_type = 'nv3dsink'if platform.processor() == 'aarch64' else 'nveglglessink'
        sink_name = _get_node_name(Flow.render, "sink")
        self._pipeline.add("nvvideoconvert", converter_name, {"gpu-id": gpu_id})
        stream_info = _parse_stream_info(self._streams[0])
        if stream_info.template:
             self._pipeline.link(
                 (stream_info.originator, converter_name),
                 (stream_info.template, '')
            )
        else:
            self._pipeline.link(stream_info.originator, converter_name)
        last_name = converter_name
        if self._batch_size > 1:
            tiler_properties = {
                "gpu-id": gpu_id,
                "width": properties.pop("width", self.DEFAULT_PICTURE_WIDTH),
                "height": properties.pop("height", self.DEFAULT_PICTURE_HEIGHT)
            }
            self._pipeline.add("nvmultistreamtiler", tiler_name, tiler_properties)
            self._pipeline.link(last_name, tiler_name)
            last_name = tiler_name
        if enable_osd:
            self._pipeline.add("nvdsosd", osd_name, {"gpu-id": gpu_id})
            self._pipeline.link(last_name, osd_name)
            last_name = osd_name

        self._pipeline.add(sink_type, sink_name, properties).link(last_name, sink_name)

        return Flow(self._pipeline, parent=self)

    def attach(self, what, name="", tips="", properties=None):
        """
        Attach a probe to the current flow
        Args:
            what:       object or name of the module that creates an object
            name:       name of the object, not applicable for explicitly created object
            tips (str): extra information for the custom object
            properties (Dict): properties to be set on the object, not applicable for explicitly created object
        Return: A derived flow
        """
        for stream in self._streams:
            stream_info = _parse_stream_info(stream)
            if not tips:
                tips = stream_info.template
            self._pipeline.attach(stream_info.originator, what, name, tips, properties)
        return Flow(self._pipeline, streams=self._streams, parent=self)

    def fork(self):
        """
        Fork a flow to support multiple processing branches
        Args: None
        Return: A derived flow
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        tee = _get_node_name(Flow.fork, "tee")
        stream_info = _parse_stream_info(self._streams[0])
        self._pipeline.add("tee", tee).link(
            (stream_info.originator, tee),
            (stream_info.template, "")
        )
        return Flow(self._pipeline, [tee], parent=self)

    def publish(self, **kwargs):
        """
        Publish generated events to a remote server
        Args:
            kwargs: standard nvmsgconv/nvmsgbroker properties
        Return: A derived flow
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        sink = _get_node_name(Flow.publish, "msgsink")
        stream_info = _parse_stream_info(self._streams[0])
        sink_properties = { "sync": False }
        _populate_kwargs(sink_properties, **kwargs)
        self._pipeline.add("nvmsgbrokersinkbin", sink, sink_properties).link(
            (stream_info.originator, sink),
            (stream_info.template, "")
        )
        return Flow(self._pipeline, parent=self)

    def encode(self, dest: str, **kwargs):
        """
        Encode the stream to a file or through RTSP streaming
        Args:
            dest(str): support "file://" and "udp://"
            kwargs: encoding options: profile/bitrate/iframeinterval
                    sink options: sync
        Return: A derived flow
        Raises: Upstream Exception
        """
        if len(self._streams) != 1:
            raise Exception("Upstream error: multiple streams must be batched")
        uri = urlparse(dest)
        to_file = True if not uri.scheme or uri.scheme == "file" else False
        if not to_file and uri.scheme != "udp" and uri.scheme != "rtsp":
            raise TypeError("Only file, rtsp or udp are supported.")
        if to_file and not os.path.splitext(uri.path)[1] in ['.mp4', '.MP4', '.mov', '.MOV']:
            raise TypeError("Only MP4 file is supported")
        if not to_file and uri.hostname and not uri.hostname in ["localhost", "127.0.0.1"]:
            raise TypeError("Only localhost is supported for streaming")

        stream_info = _parse_stream_info(self._streams[0])
        queue = _get_node_name(Flow.encode, "queue")
        converter = _get_node_name(Flow.encode, "convert")
        capsfilter = _get_node_name(Flow.encode, "capsfilter")
        encoder = _get_node_name(Flow.encode, "encoder")
        parser = _get_node_name(Flow.encode, "parser")
        mux = _get_node_name(Flow.encode, "mux")
        sink = _get_node_name(Flow.encode, "filesink")
        capsfilter_properties = { "caps": "video/x-raw(memory:NVMM), format=I420"}
        encoder_properties = {
            "profile":  kwargs["profile"] if "profile" in kwargs else 0,
            "iframeinterval":  kwargs["iframeinterval"] if "iframeinterval" in kwargs else 10,
            "bitrate": kwargs["bitrate"] if "bitrate" in kwargs else 2000000,
        }
        converter_properties = {"gpu-id": kwargs["gpu_id"] if "gpu_id" in kwargs else 0}
        file_sink_properties = { "location": uri.path, "sync": False if "sync" not in kwargs else kwargs["sync"], "async": False }
        rtsp_sink_properties = { "rtsp-port": uri.port, "sync": False if "sync" not in kwargs else kwargs["sync"], "async": False }
        udp_sink_properties = { "host": "127.0.0.1", "port": uri.port, "sync": False if "sync" not in kwargs else kwargs["sync"], "async": False }
        if uri.scheme == "rtsp":
            self._pipeline.add("queue", queue).add("nvvideoconvert", converter, converter_properties).add("nvrtspoutsinkbin", sink, rtsp_sink_properties).link(
                (stream_info.originator, queue),
                (stream_info.template, "")
            ).link(queue, converter, sink)
        else:
            self._pipeline.add("queue", queue).add("nvvideoconvert", converter, converter_properties)
            self._pipeline.add("capsfilter", capsfilter, capsfilter_properties)
            self._pipeline.add("nvv4l2h264enc", encoder, encoder_properties).add("h264parse", parser)
            if to_file:
                self._pipeline.add("mp4mux", mux).add("filesink", sink, file_sink_properties)
            else:
                self._pipeline[parser].set({"config-interval": -1})
                self._pipeline.add("rtph264pay", mux).add("udpsink", sink, udp_sink_properties)

            self._pipeline.link(
                (stream_info.originator, queue),
                (stream_info.template, "")
            ).link(queue, converter, capsfilter, encoder, parser, mux, sink)

        return Flow(self._pipeline, parent=self)