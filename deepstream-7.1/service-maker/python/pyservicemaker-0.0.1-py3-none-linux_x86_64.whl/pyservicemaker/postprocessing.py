#
# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#
from abc import ABC, abstractmethod
from typing import Any, List, Dict

class PostProcessing(ABC):
    """Base tensor output post-processing class"""

    @abstractmethod
    def __call__(self, output_layers: Dict) -> Any:
        """
        Convert output tensors to real world representation.

        Args:
            output_layers: direct output layers from the model, iterables in format of (name, tensor)
        """

class ObjectDetectorOutputConverter(PostProcessing):
    """Base tensor output post-processing for object detection model"""
    @abstractmethod
    def __call__(self, output_layers: Dict) -> List:
        """
        Convert output tensors to object detection results

        Args:
            output_layers: direct output layers from the model, dictionary of (name, tensor)
        return:
            List of BBox tensor ``(class_id, confidence, x1, y1, x2, y2)``
        """
